
public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RegistrationFrame r = new RegistrationFrame();
		
	}

}
